"""AI Core configuration module.

This module provides utilities to load AI Core credentials from mounted secrets or environment
variables and configure them for use with LiteLLM.
"""

import json
import logging
import os
from typing import Optional

from sap_cloud_sdk.core.secret_resolver import resolve_base_mount
from sap_cloud_sdk.core.telemetry.metrics_decorator import record_metrics
from sap_cloud_sdk.core.telemetry.module import Module
from sap_cloud_sdk.core.telemetry.operation import Operation
from .completion import acompletion, completion
from .filtering import (
    AzureContentFilter,
    ContentFilter,
    ContentFilteredError,
    ContentFiltering,
    InputFiltering,
    LlamaGuard38bFilter,
    OrchestrationError,
    OutputFiltering,
    Severity,
    disable_filtering,
    set_filtering,
)

logger = logging.getLogger(__name__)


def _get_secret(
    env_var_name: str,
    file_name: Optional[str] = None,
    default: str = "",
    instance_name: str = "aicore-instance",
) -> str:
    """
    Get a secret value with the following priority:
    1. Try to read from /etc/secrets/appfnd/aicore/{instance_name}/{file_name}
    2. Fall back to environment variable {env_var_name}
    3. Return default value if neither exists

    Args:
        env_var_name: Name of the environment variable
        file_name: Name of the secret file (if None, uses env_var_name)
        default: Default value if neither source has the secret
        instance_name: Name of the aicore instance defined in app.yaml. Defaults to aicore-instance

    """
    resolved_base_path = resolve_base_mount()
    secrets_base_path = f"{resolved_base_path}/aicore/{instance_name}"
    secret_file_name = file_name if file_name else env_var_name
    secret_file_path = os.path.join(secrets_base_path, secret_file_name)

    # Try reading from file first
    if os.path.exists(secret_file_path):
        try:
            with open(secret_file_path, "r") as f:
                value = f.read().strip()
                if value:
                    logger.info(f"Loaded {env_var_name} from file: {secret_file_path}")
                    return value
        except Exception as e:
            logger.warning(
                f"Failed to read {env_var_name} from {secret_file_path}: {e}"
            )

    # Fall back to environment variable
    value = os.environ.get(env_var_name, default)
    if value:
        logger.info(f"Loaded {env_var_name} from environment variable")
    else:
        logger.warning(f"No value found for {env_var_name}, using default")

    return value


def _get_aicore_base_url(instance_name: str = "aicore-instance") -> str:
    """
    Get AICORE_BASE_URL with special handling for serviceurls JSON structure.
    The serviceurls file contains a JSON object with AI_API_URL field.

    Returns:
        Base URL for AI Core service
    """
    resolved_base_path = resolve_base_mount()
    secrets_base_path = f"{resolved_base_path}/aicore/{instance_name}"
    serviceurls_file = os.path.join(secrets_base_path, "serviceurls")

    # Try reading from serviceurls file
    if os.path.exists(serviceurls_file):
        try:
            with open(serviceurls_file, "r") as f:
                serviceurls_data = json.loads(f.read().strip())
                ai_api_url = serviceurls_data.get("AI_API_URL", "")
                if ai_api_url:
                    logger.info(f"Loaded AICORE_BASE_URL from file: {serviceurls_file}")
                    return ai_api_url
        except Exception as e:
            logger.warning(
                f"Failed to read AICORE_BASE_URL from {serviceurls_file}: {e}"
            )

    # Fall back to environment variable
    value = os.environ.get("AICORE_BASE_URL", "")
    if value:
        logger.info("Loaded AICORE_BASE_URL from environment variable")
    else:
        logger.warning("No value found for AICORE_BASE_URL")

    return value


@record_metrics(Module.AICORE, Operation.AICORE_SET_CONFIG)
def set_aicore_config(instance_name: str = "aicore-instance") -> None:
    """Load AI Core credentials and activate content filtering.

    Loads secrets from files or environment variables and sets them as
    process env vars so ``litellm`` picks them up.

    File mappings based on the Kubernetes secret structure:
        clientid → AICORE_CLIENT_ID
        clientsecret → AICORE_CLIENT_SECRET
        url → AICORE_AUTH_URL
        serviceurls (JSON with AI_API_URL) → AICORE_BASE_URL

    After credentials are loaded, content filtering is activated on every
    ``sap/*`` LiteLLM call at the configured thresholds (default: severity
    ``MEDIUM`` on all categories + prompt shield enabled). Override via
    ``AICORE_FILTER_*`` env vars set *before* calling this function, or
    call :func:`set_filtering` afterward. Use :func:`disable_filtering`
    to turn filtering off at runtime, or set ``AICORE_FILTER_ENABLED=false``
    to keep it off entirely.
    """
    # Load secrets
    client_id = _get_secret("AICORE_CLIENT_ID", "clientid", instance_name=instance_name)
    client_secret = _get_secret(
        "AICORE_CLIENT_SECRET", "clientsecret", instance_name=instance_name
    )
    auth_url = _get_secret("AICORE_AUTH_URL", "url", instance_name=instance_name)
    base_url = _get_aicore_base_url(instance_name)
    resource_group = _get_secret(
        "AICORE_RESOURCE_GROUP", default="default", instance_name=instance_name
    )

    # Ensure AICORE_AUTH_URL has /oauth/token suffix
    if auth_url and not auth_url.endswith("/oauth/token"):
        auth_url = auth_url.rstrip("/") + "/oauth/token"

    if base_url and not base_url.endswith("/v2"):
        base_url = base_url.rstrip("/") + "/v2"

    # Set environment variables for LiteLLM
    if client_id:
        os.environ["AICORE_CLIENT_ID"] = client_id
    if client_secret:
        os.environ["AICORE_CLIENT_SECRET"] = client_secret
    if auth_url:
        os.environ["AICORE_AUTH_URL"] = auth_url
    if base_url:
        os.environ["AICORE_BASE_URL"] = base_url
    if resource_group:
        os.environ["AICORE_RESOURCE_GROUP"] = resource_group

    # Log configuration completion (excluding sensitive information)
    logger.info("AI Core configuration has been set successfully")

    # Activate content filtering for all sap/* LiteLLM model calls.
    # AICORE_FILTER_ENABLED=false disables; AICORE_FILTER_* tune thresholds.
    # Errors propagate — filtering misconfiguration should surface at startup
    # rather than be swallowed silently.
    set_filtering()


__all__ = [
    "set_aicore_config",
    "set_filtering",
    "disable_filtering",
    "completion",
    "acompletion",
    "ContentFiltering",
    "InputFiltering",
    "OutputFiltering",
    "AzureContentFilter",
    "LlamaGuard38bFilter",
    "ContentFilter",
    "Severity",
    "ContentFilteredError",
    "OrchestrationError",
]
